#!/usr/bin/php
<?php


  $opts = getopt('h:');

  if (isset($opts['H']))
  {
    show_usage();
  }

  switch($argv[3])
  {
    case 'index':
      do_query('10.200.200.10');
      break;
    case 'query':
      do_query('10.200.200.10', true);
      break;
    case 'get':
      do_get($argv);
      break;
  }

  function get_data($host)
  {
    $ret = snmp2_get($host, 'public', 'NET-SNMP-EXTEND-MIB::nsExtendOutputFull."xen-stats"');
    return $ret;
  }

  function do_get($params)
  {
    $data = explode("\n", get_data('10.200.200.10'));
    $data = str_replace('STRING: ', '', $data);
    $hosts = array();
    foreach($data as $d)
    {
      $host = array();
      foreach(explode(',', $d) as $datapair)
      {
        list($key, $val) = explode(':', $datapair);
        $host[trim($key)] = trim($val);
      }
      $hosts[$host['name']] = $host;
    }
    echo $hosts[$params[5]][$params[4]];
  }

  function do_query($host, $whatever = false)
  {
    $matches = array();
    preg_match_all('/name: ([^,]+)/', get_data($host), $matches);
    foreach($matches[1] as $host)
    {
      if ($whatever)
      {
        echo "{$host}:{$host}\n";
      }
      else
      {
        echo $host . "\n";
      }
    }
  }

